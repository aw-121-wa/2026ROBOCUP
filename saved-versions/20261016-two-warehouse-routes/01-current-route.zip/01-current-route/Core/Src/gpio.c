/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    gpio.c
  * @brief   This file provides code for the configuration
  *          of all used GPIO pins.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "gpio.h"

/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/*----------------------------------------------------------------------------*/
/* Configure GPIO                                                             */
/*----------------------------------------------------------------------------*/
/* USER CODE BEGIN 1 */

/* USER CODE END 1 */

/** Configure pins as
        * Analog
        * Input
        * Output
        * EVENT_OUT
        * EXTI
*/
void MX_GPIO_Init(void)
{

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOE_CLK_ENABLE();

  GPIO_InitTypeDef inputs={0};
  inputs.Pin=GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_3; /* Four active-low gray sensors. */
  inputs.Mode=GPIO_MODE_INPUT;
  inputs.Pull=GPIO_PULLUP;
  HAL_GPIO_Init(GPIOD,&inputs);
  inputs.Pin=GPIO_PIN_13; /* Rear gray sensor migrated from PD8. */
  HAL_GPIO_Init(GPIOB,&inputs);
  inputs.Pin=GPIO_PIN_10; /* Pillar IR input PD10, active low. */
  HAL_GPIO_Init(GPIOD,&inputs);

}

/* USER CODE BEGIN 2 */

/* USER CODE END 2 */
